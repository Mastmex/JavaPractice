package lesson4;

public interface EmployeePosition {
    String getJobTitle();
    int calcSalary(int baseSalary);
}
